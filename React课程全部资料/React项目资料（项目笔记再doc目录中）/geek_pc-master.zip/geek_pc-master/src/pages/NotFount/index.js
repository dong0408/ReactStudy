export default function NotFound() {
  return <div>还有counter秒</div>
}
