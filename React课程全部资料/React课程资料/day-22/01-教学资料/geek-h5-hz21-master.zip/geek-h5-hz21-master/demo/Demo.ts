// type User = {
//   name: string
//   age: number
// }

// function show(user: User | null) {
//   console.log(user.age)
//   console.log(user.age)
// }

// show(null)
