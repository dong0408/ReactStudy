import { createBrowserHistory } from 'history'
// 手动自己创建history
const history = createBrowserHistory()

export default history
