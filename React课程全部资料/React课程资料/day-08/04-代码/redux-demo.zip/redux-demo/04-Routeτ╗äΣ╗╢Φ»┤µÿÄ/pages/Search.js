import React from 'react'

export default function Search() {
  return <div>搜索组件</div>
}
