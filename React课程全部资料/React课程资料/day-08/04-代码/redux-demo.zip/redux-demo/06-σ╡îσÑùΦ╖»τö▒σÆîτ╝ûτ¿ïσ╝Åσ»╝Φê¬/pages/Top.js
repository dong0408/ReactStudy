import React from 'react'

export default function Top() {
  return <div>排行榜</div>
}
