import './index.scss'

const Home = () => {
  return <div className="home" />
}

export default Home
