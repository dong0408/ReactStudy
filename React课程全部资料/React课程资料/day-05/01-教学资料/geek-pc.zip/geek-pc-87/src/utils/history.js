/**
 * 手动创建一个 history 对象
 */

import { createBrowserHistory } from 'history'

// 手动创建一个 基于 Browser 的 history 对象
const history = createBrowserHistory()

export { history }
