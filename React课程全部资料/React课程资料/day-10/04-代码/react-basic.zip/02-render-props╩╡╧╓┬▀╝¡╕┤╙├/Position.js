const Position = () => (
  <div>
    <h3>当前鼠标的位置</h3>
    <div>(0, 0)</div>
  </div>
)
export default Position
