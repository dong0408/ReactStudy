import { Component } from 'react'

class Hello extends Component {
  render() {
    return <div>我是一个Hello组件</div>
  }
}
export default Hello
