const Demo = () => <div>我是一个函数组件</div>
export default Demo
