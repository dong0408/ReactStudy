export default function Man() {
  return (
    <div>
      <h3>男人组件</h3>
      <div>金钱：</div>
      <button>搬砖</button>
    </div>
  )
}
