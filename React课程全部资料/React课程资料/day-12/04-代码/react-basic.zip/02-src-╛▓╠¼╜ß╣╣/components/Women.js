export default function Women() {
  return (
    <div>
      <h3>女人组件</h3>
      <div>金钱：</div>
      <button>买包</button>
    </div>
  )
}
