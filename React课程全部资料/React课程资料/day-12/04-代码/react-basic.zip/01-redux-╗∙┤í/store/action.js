export const add = () => ({ type: 'ADD' })
export const minus = () => ({ type: 'MINUS' })
