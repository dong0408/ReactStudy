export default function filter(state = 'all', action) {
  return state
}
