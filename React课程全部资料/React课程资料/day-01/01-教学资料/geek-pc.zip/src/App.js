import { Router, Route, Switch, Redirect } from 'react-router-dom'

import NotFound from './pages/NotFound'
import Login from './pages/Login'
import Layout from './pages/Layout'

import { AuthRoute } from './components/AuthRoute'
import { history } from './utils/history'

import './App.css'

function App() {
  return (
    <Router history={history}>
      <div className="App">
        <Switch>
          <Route exact path="/">
            <Redirect to="/home"></Redirect>
          </Route>
          <AuthRoute path="/home" component={Layout}></AuthRoute>
          <Route path="/login">
            <Login></Login>
          </Route>
          <Route path="*">
            <NotFound></NotFound>
          </Route>
        </Switch>
      </div>
    </Router>
  )
}

export default App
