import { Route } from 'react-router-dom'
import { isAuth } from '../../utils/token'

const AuthRoute = ({ component: Component, ...rest }) => {
  return (
    <Route
      {...rest}
      render={props => {
        if (!isAuth()) {
          return props.history.push('/login')
        }
        return <Component {...props} />
      }}
    />
  )
}

export { AuthRoute }
