import { Component } from 'react'
import { Route, Link } from 'react-router-dom'
import { Layout, Menu, Popconfirm } from 'antd'
import {
  HomeOutlined,
  DiffOutlined,
  EditOutlined,
  LogoutOutlined
} from '@ant-design/icons'

import { clearToken } from '../../utils/token'

import Home from '../Home'
import Article from '../Article'
import Publish from '../Publish'

import './index.scss'

const { Header, Sider } = Layout

class GeekLayout extends Component {
  state = {
    selectedKey: ''
  }

  // https://github.com/ant-design/ant-design/issues/1575#issuecomment-362488383
  setSelectedKey = () => {
    console.log(this.props)
    let selectedKey = this.props.location.pathname
    if (selectedKey.startsWith('/home/publish')) {
      selectedKey = '/home/publish'
    }

    this.setState({
      selectedKey
    })
  }

  componentDidMount() {
    this.setSelectedKey()
  }

  componentDidUpdate(prevProps) {
    if (prevProps.location.pathname !== this.props.location.pathname) {
      this.setSelectedKey()
    }
  }

  onLogout = () => {
    clearToken()
    this.props.history.push('/login')
  }

  render() {
    return (
      <Layout>
        <Header className="header">
          <div className="logo" />

          <div className="user-info">
            <span className="user-name">1388888888</span>
            <span className="user-logout">
              <Popconfirm
                title="是否确认退出？"
                onConfirm={this.onLogout}
                okText="退出"
                cancelText="取消"
              >
                <LogoutOutlined /> 退出
              </Popconfirm>
            </span>
          </div>
        </Header>
        <Layout>
          <Sider width={200}>
            <Menu
              mode="inline"
              theme="dark"
              selectedKeys={[this.state.selectedKey]}
              style={{ height: '100%', borderRight: 0 }}
            >
              <Menu.Item icon={<HomeOutlined />} key="/home">
                <Link to="/home">数据概览</Link>
              </Menu.Item>
              <Menu.Item icon={<DiffOutlined />} key="/home/article">
                <Link to="/home/article">内容管理</Link>
              </Menu.Item>
              <Menu.Item icon={<EditOutlined />} key="/home/publish">
                <Link to="/home/publish">发布文章</Link>
              </Menu.Item>
            </Menu>
          </Sider>
          <Layout className="layout-content" style={{ padding: 20 }}>
            <Route exact path="/home">
              <Home></Home>
            </Route>
            <Route path="/home/article" component={Article}></Route>
            <Route path="/home/publish/:articleId?" component={Publish}></Route>
          </Layout>
        </Layout>
      </Layout>
    )
  }
}

export default GeekLayout
