import './index.scss'

const Home = () => {
  return <div className="home"></div>
}

export default Home
