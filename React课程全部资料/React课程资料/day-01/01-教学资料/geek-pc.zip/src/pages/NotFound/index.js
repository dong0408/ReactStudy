const NotFound = () => 404
export default NotFound
